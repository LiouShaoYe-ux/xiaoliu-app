@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 小刘电子 - 电脑端摄像头监控
echo.
echo ============================================
echo   小刘电子 · 电脑端摄像头监控
echo ============================================
echo.

where node >nul 2>nul
if %errorlevel%==0 (
    echo  使用 Node 启动...
    echo.
    node cam_server.js
    goto :finish
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo  使用 Python 启动...
    echo.
    python cam_server.py
    goto :finish
)

echo  没找到 Node.js 或 Python。
echo  请先安装 Node.js（https://nodejs.org）或 Python（https://python.org）
echo  装好后再双击本文件。
echo.

:finish
echo.
echo  服务已结束。按任意键关闭窗口。
pause >nul

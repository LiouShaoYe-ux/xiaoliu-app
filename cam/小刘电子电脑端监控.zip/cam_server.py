#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# 小刘电子 · 电脑端摄像头推流服务（零依赖，Python 3）
# 用法：python cam_server.py   或双击「启动监控.bat」
import os
import socket
import threading
import json
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = 8899
BASE = os.path.dirname(os.path.abspath(__file__))

state = {"data": None, "time": 0, "count": 0}
lock = threading.Lock()


def local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _text(self, text, code=200):
        body = text.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path in ("/", "/index.html", "/monitor.html"):
            f = os.path.join(BASE, "monitor.html")
            try:
                with open(f, "rb") as fp:
                    data = fp.read()
            except Exception:
                self._text("找不到 monitor.html，请确认它在同一目录", 500)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/latest.jpg":
            with lock:
                data = state["data"]
            if data is None:
                self._text("no frame yet", 404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)
            return

        if path == "/config":
            self._json({"ip": local_ip(), "port": PORT})
            return

        if path == "/info":
            with lock:
                self._json({
                    "hasFrame": state["data"] is not None,
                    "frames": state["count"],
                    "lastTime": state["time"],
                })
            return

        self._text("not found", 404)

    def do_POST(self):
        path = self.path.split("?")[0]
        if path != "/frame":
            self._text("not found", 404)
            return
        try:
            length = int(self.headers.get("Content-Length", 0))
        except Exception:
            length = 0
        if length <= 0:
            self._text("empty", 400)
            return
        data = self.rfile.read(length)
        if len(data) > 200:
            import time as _t
            with lock:
                state["data"] = data
                state["time"] = int(_t.time() * 1000)
                state["count"] += 1
        self._text("ok")


def main():
    ip = local_ip()
    print("")
    print("============================================")
    print("  小刘电子 · 电脑端摄像头监控已启动")
    print("============================================")
    print("  电脑本机打开：  http://127.0.0.1:%d" % PORT)
    print("  手机端填地址：  %s:%d" % (ip, PORT))
    print("--------------------------------------------")
    print("  手机与电脑需在同一 WiFi；关闭本窗口即停止")
    print("============================================")
    print("")
    try:
        webbrowser.open("http://127.0.0.1:%d" % PORT)
    except Exception:
        pass
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()


if __name__ == "__main__":
    main()

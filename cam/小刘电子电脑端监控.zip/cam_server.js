// 小刘电子 · 电脑端摄像头推流服务（零依赖，Node.js）
// 用法：node cam_server.js   或双击「启动监控.bat」
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { exec } = require('child_process');

const PORT = 8899;
const BASE = __dirname;

let latest = null;
let latestTime = 0;
let frameCount = 0;

function localIPs() {
  const list = [];
  const ifaces = os.networkInterfaces();
  for (const name of Object.keys(ifaces)) {
    for (const item of ifaces[name] || []) {
      if (item.family === 'IPv4' && !item.internal) {
        list.push({ name: name, address: item.address });
      }
    }
  }
  return list;
}

// 优先 192.168 网段的 WiFi/有线网卡，排除 169.254 这类无效地址
function pickIP(list) {
  if (!list.length) return '127.0.0.1';
  const usable = list.filter(function (x) { return !/^169\.254\./.test(x.address); });
  const pool = usable.length ? usable : list;

  const p192 = pool.filter(function (x) { return /^192\.168\./.test(x.address); });
  const named = p192.filter(function (x) {
    return /wi-?fi|wlan|无线|以太|ethernet/i.test(x.name);
  });
  if (named.length) return named[0].address;
  if (p192.length) return p192[0].address;

  const p10 = pool.filter(function (x) { return /^10\./.test(x.address); });
  if (p10.length) return p10[0].address;

  const p172 = pool.filter(function (x) {
    return /^172\.(1[6-9]|2\d|3\d)\./.test(x.address);
  });
  if (p172.length) return p172[0].address;

  return pool[0].address;
}

function localIP() {
  return pickIP(localIPs());
}

function sendJSON(res, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(body);
}

const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];

  // 网页 POST 上来的 JPEG 帧
  if (req.method === 'POST' && url === '/frame') {
    const chunks = [];
    req.on('data', (d) => chunks.push(d));
    req.on('end', () => {
      const buf = Buffer.concat(chunks);
      if (buf.length > 200) {
        latest = buf;
        latestTime = Date.now();
        frameCount++;
      }
      res.writeHead(200, { 'Content-Type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
      res.end('ok');
    });
    return;
  }

  // 手机 App 取最新一帧
  if (url === '/latest.jpg') {
    if (!latest) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('no frame yet');
      return;
    }
    res.writeHead(200, {
      'Content-Type': 'image/jpeg',
      'Content-Length': latest.length,
      'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*'
    });
    res.end(latest);
    return;
  }

  if (url === '/config') {
    const list = localIPs();
    sendJSON(res, {
      ip: pickIP(list),
      port: PORT,
      all: list.map(function (x) { return x.address; })
    });
    return;
  }

  if (url === '/info') {
    sendJSON(res, {
      hasFrame: !!latest,
      frames: frameCount,
      lastTime: latestTime,
      ageMs: latestTime ? Date.now() - latestTime : -1
    });
    return;
  }

  if (url === '/' || url === '/index.html' || url === '/monitor.html') {
    const file = path.join(BASE, 'monitor.html');
    fs.readFile(file, (err, data) => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end('找不到 monitor.html，请确认它在同一目录');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(data);
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('not found');
});

server.listen(PORT, '0.0.0.0', () => {
  const ip = localIP();
  console.log('');
  console.log('============================================');
  console.log('  小刘电子 · 电脑端摄像头监控已启动');
  console.log('============================================');
  console.log('  电脑本机打开：  http://127.0.0.1:' + PORT);
  console.log('  手机端填地址：  ' + ip + ':' + PORT);
  console.log('--------------------------------------------');
  console.log('  手机与电脑需在同一 WiFi；关闭本窗口即停止');
  console.log('============================================');
  console.log('');
  try {
    exec('start "" http://127.0.0.1:' + PORT);
  } catch (e) { /* 非 Windows 忽略 */ }
});

server.on('error', (err) => {
  if (err && err.code === 'EADDRINUSE') {
    console.log('端口 ' + PORT + ' 被占用，请关掉之前的窗口再试，或改脚本里的 PORT。');
  } else {
    console.log('启动失败：' + err);
  }
  setTimeout(() => process.exit(1), 3000);
});
